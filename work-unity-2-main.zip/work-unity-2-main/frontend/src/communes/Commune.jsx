import React, { useEffect, useState } from "react";
import "./Commune.css";

export const Commune = () => {
  const [communes, setCommunes] = useState([]);

  const getCommuneData = async () => {
    const result = await fetch("http://localhost:3000/commune", {
      method: "GET",
    });
    const information = await result.json();
    setCommunes(information);
  };

  useEffect(() => {
    getCommuneData();
  }, []);

  return (
    <div className="container-commune">
      {communes.map((c) => (
        <div key={c.id}>
          <p>{c.name}</p>
          <p>{c.province}</p>
          <p>{c.address}</p>
          <p>{c.mayor}</p>
          <p>{c.surface}</p>
          <p>{c.population}</p>
        </div>
      ))}
    </div>
  );
};
