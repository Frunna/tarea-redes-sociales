## Instalar y ejecutar en modo desarrollo

### Backend

* Abrir una terminal
* Situarse en la carpeta `backend`
* Ejecutar `npm install`
* Ejecutar `npm run dev`

### Frontend
* Abrir una terminal
* Situarse en la carpeta `frontend`
* Ejecutar `npm install`
* Ejecutar `npm run dev`
